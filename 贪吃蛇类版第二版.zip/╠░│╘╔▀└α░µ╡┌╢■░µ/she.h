#pragma once
#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
#include<string>
#include<graphics.h>
#include<mmstream.h>//����ͷ�ļ�
#include"food.h"
#pragma comment (lib,"winmm.lib")//���ֿ��ļ�

class she :public food
{
public:
	void dayinshe();
	void snakemove();
	void xunhuan();
	void shubiao();
};