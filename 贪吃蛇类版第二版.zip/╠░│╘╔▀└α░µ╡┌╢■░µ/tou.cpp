#include<stdio.h>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
#include<string>
#include<graphics.h>
#include<mmstream.h>//����ͷ�ļ�
#include"tou.h"
#pragma comment (lib,"winmm.lib")//���ֿ��ļ�
chessboard::chessboard()
{

	//��ӡͼƬ
	loadimage(NULL, _T("./beijing.png"));
	
	 
	//��ʼ��
	n = 3;
	ch = ch::right;
	sd = 10;
	sdz = 100;
	r = 255;
	g = 0;
	b = 0;
	szbx[0] = 100;
	szby[0] = 100;
	szbx[1] = 80;
	szby[1] = 100;
	szbx[2] = 60;
	szby[2] = 100;
	gq = 1;
	//��ʼ��ʳ��
	iseat = true;//��ʼĬ��ʳ�ﱻ�Ե�
}//��ʼ����
void chessboard::keyDown()//��������
{
	char userKey = _getch();
	if (userKey == -32)			// �������Ƿ����
		userKey = -_getch();	// ��ȡ���巽�򣬲�������������ĸ�� ASCII ��ͻ
	switch (userKey)
	{
	case 'w':
	case 'W':
	case -72:
		if (ch != down)
			ch = up;
		break;
	case 's':
	case 'S':
	case -80:
		if (ch != up)
			ch = down;
		break;
	case 'a':
	case 'A':
	case -75:
		if (ch != ch::right)
			ch = ch::left;
		break;
	case 'd':
	case 'D':
	case -77:
		if (ch != ch::left)
			ch = ch::right;
		break;
	case 'p':
	case 'P':
		mciSendString(_T("stop mymusic"), 0, 0, 0);
		MessageBox(NULL, "���ȷ��������Ϸ","��Ϸ��ͣ", MB_OK);
		mciSendString(_T("play mymusic"), 0, 0, 0);
		break;
	}
}
void  chessboard::jies()
{
	mciSendString(_T("close mymusic"), 0, 0, 0);
	mciSendString(_T("close mmusic"), 0, 0, 0);
	mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
	//���Ű�������
	mciSendString(_T("play mmusic "), 0, 0, 0);
	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	rectangle(0, 220, 640, 270);
	outtextxy(225, 220, "��Ϸ����");
	//��ʼ��
	n = 3;
	ch = ch::right;
	sd = 10;
	sdz = 100;
	r = 255;
	g = 0;
	b = 0;
	szbx[0] = 100;
	szby[0] = 100;
	szbx[1] = 80;
	szby[1] = 100;
	szbx[2] = 60;
	szby[2] = 100;
	gq = 1;
	Sleep(2000);
}
int chessboard::gameover()
{

	if (gq == 1) {
		//��ײ��1
		if (szbx[0] > 105 && szbx[0] < 145) {
			if (szby[0] ==155 || szby[0] ==195)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 155 && szby[0] < 195) {
			if (szbx[0] == 105 || szbx[0] == 145)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��2
		if (szbx[0] > 310 && szbx[0] < 340) {
			if (szby[0] == 160 || szby[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 160 && szby[0] < 190) {
			if (szbx[0] == 310 || szbx[0] == 340)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
	}
	if (gq == 2) {
		//��ײ��1
		if (szbx[0] > 310 && szbx[0] < 390) {
			if (szby[0] == 160 || szby[0] == 240)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 160 && szby[0] < 240) {
			if (szbx[0] == 310 || szbx[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��2
		if (szbx[0] > 110 && szbx[0] < 190) {
			if (szby[0] == 260 || szby[0] == 340)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 260 && szby[0] < 340) {
			if (szbx[0] == 110 || szbx[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��3
		if (szbx[0] > 310 && szbx[0] < 390) {
			if (szby[0] == 360 || szby[0] == 440)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 360 && szby[0] < 440) {
			if (szbx[0] == 310 || szbx[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
	}
	if (gq == 4)
	{
		//��ײ��1
		if (szby[0] > 160 && szby[0] < 190)
		{
			if (szbx[0] == 60 || szbx[0] == 90)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}
			}
		}
		if (szbx[0] > 60 && szbx[0] < 90)
		{
			if (szby[0] == 160 || szby[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��2
		if (szbx[0] > 160 && szbx[0] < 190) {
			if (szby[0] == 160 || szby[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 160 && szby[0] < 190) {
			if (szbx[0] == 160 || szbx[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��3
		if (szbx[0] > 260 && szbx[0] < 290) {
			if (szby[0] == 160 || szby[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 160 && szby[0] < 190) {
			if (szbx[0] == 260 || szbx[0] == 290)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��4		
		if (szbx[0] > 360 && szbx[0] < 390) {
			if (szby[0] == 160 || szby[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 160 && szby[0] < 190) {
			if (szbx[0] == 360 || szbx[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//����ײ��5
		if (szby[0] > 360 && szby[0] < 390)
		{
			if (szbx[0] == 60 || szbx[0] == 90)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}
			}
		}
		if (szbx[0] > 60 && szbx[0] < 90)
		{
			if (szby[0] == 360 || szby[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		//��ײ��6
		if (szbx[0] > 160 && szbx[0] < 190)
		{
			if (szby[0] == 360 || szby[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 350 && szby[0] < 400)
		{
			if (szbx[0] == 160 || szbx[0] == 190)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}
			}
		}
		//��ײ��7
		if (szbx[0] > 260 && szbx[0] < 290)
		{
			if (szby[0] == 360 || szby[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 360 && szby[0] < 390)
		{
			if (szbx[0] == 260 || szbx[0] == 290)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}
			}
		}
		//��ײ��8
		if (szbx[0] > 360 && szbx[0] < 390)
		{
			if (szby[0] == 360 || szby[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}

			}
		}
		if (szby[0] > 360 && szby[0] < 390)
		{
			if (szbx[0] == 360 || szbx[0] == 390)
			{
				if (sm > 0) {
					ch = ch::right;
					sd = 10;
					szbx[0] = 100;
					szby[0] = 100;
					szbx[1] = 90;
					szby[1] = 100;
					szbx[2] = 80;
					szby[2] = 100;
					sm = sm - 1;
				}
				else
				{
					sm = 1;
					n = 3;
					gq = 1;
					sdz = 100;
					jies();
					return 1;
				}
			}
		}
	}
	//��ǽ��ײ
	if (szbx[0] < 0 || szbx[0]>440 || szby[0] < 0 || szby[0]>470)
	{
		if (sm > 0) {
			//��ʼ��
			ch = ch::right;
			sd = 10;
			szbx[0] = 100;
			szby[0] = 100;
			szbx[1] = 90;
			szby[1] = 100;
			szbx[2] = 80;
			szby[2] = 100;
			sm = sm - 1;
		}
		else
		{
			sm = 1;
			n = 3;
			gq = 1;
			sdz = 100;
			jies();
			return 1;
		}
	}
	//���Լ���ײ

	for (int i = 1; i < n - 1; i++)
	{
		if (szbx[0] == szbx[i] && szby[0] == szby[i])
		{
			if (sm > 0) {
				//��ʼ��
				//��ʼ��
				ch = ch::right;
				sd = 10;
				szbx[0] = 100;
				szby[0] = 100;
				szbx[1] = 90;
				szby[1] = 100;
				szbx[2] = 80;
				szby[2] = 100;
				sm = sm - 1;
			}
			else {
				sm = 1;
				n = 3;
				gq = 1;
				sdz = 100;
				jies();
				return 1;//����1��main�������ifΪ��
			}
		}
	}
	return 0;
}
void chessboard::fenshu()//�÷ּ���
{



	//�������ֵĴ�С       ����
	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(14, 214, 99));
	char num[20];//ת���ַ���
	sprintf(num, "%d", n);
	outtextxy(450, 20, "����:");
	outtextxy(570, 20, num);//���λ��

	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(14, 214, 99));
	char nun[20];//ת���ַ���
	sprintf(nun, "%d", sdz);
	outtextxy(450, 70, "�ٶ�:");
	outtextxy(570, 70, nun);//���λ��

	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(14, 214, 99));
	char smm[20];//ת���ַ���
	sprintf(smm, "%d", sm);
	outtextxy(450, 120, "����:");
	outtextxy(570, 120, smm);//���λ��
	//�ؿ�
	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(14, 214, 99));
	char gqs[20];//ת���ַ���
	sprintf(gqs, "%d", gq);
	outtextxy(450, 170, "�ؿ�:");
	outtextxy(570, 170, gqs);//���λ��

	//��ʾ
	settextstyle(30, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(255, 127, 39));
	outtextxy(450, 270, "һ���Ĺ�");
	settextstyle(20, 0, _T("����"));
	outtextxy(450, 300, "W,S,A,D����");
	outtextxy(450, 320, "��,��,��,�ҿ���");
	outtextxy(450, 340, "P����ͣ");

}
void chessboard::guanqi()
{
	line(450, 0, 450, 480);
	if (gq == 1) {

	}
}
void chessboard::szc()//��ӡ��������
{
	cleardevice();
	setlinecolor(RED);
	loadimage(NULL, _T("./tcs1.png"));
	fillrectangle(160, 150, 480, 200);
	fillrectangle(160, 210, 480, 260);
	fillrectangle(160, 270, 480, 320);
	fillrectangle(160, 330, 480, 380);
	char smm[20];//ת���ַ���
	sprintf(smm, "%d", sm);
	outtextxy(145, 150, "�� ");
	outtextxy(255, 150, "����");
	outtextxy(355, 150, smm);//���λ��
	outtextxy(425, 150, " ��");
	char nun[20];//ת���ַ���
	sprintf(nun, "%d", sdz);
	outtextxy(145, 210, "�� ");
	outtextxy(255, 210, "�ٶ�");
	outtextxy(355, 210, nun);//���λ��
	outtextxy(425, 210, " ��");

	char gqs[20];//ת���ַ���
	sprintf(gqs, "%d", gq);
	outtextxy(145, 270, "�� ");
	outtextxy(255, 270, "�ؿ�");
	outtextxy(355, 270, gqs);//���λ��
	outtextxy(425, 270, " ��");
	outtextxy(255, 330, "�˳�");


}
void chessboard::shezhs()
{

	cleardevice();

	loadimage(NULL, _T("./tcs1.png"));

	szc();
	while (1) {
		shubiao2();
		if(dj==1)
		{
			dj = 0;
			szc();
		}
		if (fh == 1)
		{
			fh = 0;
			break;
		}
		BeginBatchDraw();
		EndBatchDraw();//����
	}
}
void chessboard::shubiao2() {//���д��
	while (1)
	{
		if (MouseHit())
		{

			MOUSEMSG s = GetMouseMsg();
			//����
			if (s.x > 160 and s.x < 200 and s.y>150 and s.y < 200) 
			{
				setlinecolor(BLACK);
				rectangle(160, 150, 200, 200);

			}
			if (s.x > 440 and s.x < 480 and s.y>150 and s.y < 200)
			{
				setlinecolor(BLACK);
				rectangle(440, 150, 480, 200);

			}
			//�ٶ�
			if (s.x > 160 and s.x < 210 and s.y>210 and s.y < 260)
			{
				setlinecolor(BLACK);
				rectangle(160, 210, 200, 260);

			}
			if (s.x > 440 and s.x < 480 and s.y>210 and s.y < 260)
			{
				setlinecolor(BLACK);
				rectangle(440, 210, 480, 260);

			}
			//�ؿ�
			if (s.x > 160 and s.x < 210 and s.y>270 and s.y < 320)
			{
				setlinecolor(BLACK);
				rectangle(160, 270, 200, 320);

			}
			if (s.x > 440 and s.x < 480 and s.y>270 and s.y < 320)
			{
				setlinecolor(BLACK);
				rectangle(440, 270, 480, 320);

			}
			//�˳�
			if (s.x > 160 and s.x < 480 and s.y>330 and s.y < 380)
			{
				setlinecolor(BLACK);
				rectangle(160, 330, 480, 380);
			}
			switch (s.uMsg)
			{
			case WM_LBUTTONDOWN:
				if (s.x > 160 and s.x < 200 and s.y>150 and s.y < 200)//����
				{

					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					if (sm > 1)
					{
						sm = sm - 1;
					}
					dj = 1;
					break;
				}
				if (s.x > 440 and s.x < 480 and s.y>150 and s.y < 200)//����
				{
					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					if (sm < 10)
					{
						sm = sm + 1;
					}
					dj = 1;
					break;
				}
				if (s.x > 160 and s.x < 200 and s.y>210 and s.y < 260)//�ٶ�
				{
					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					if (sdz > 10)
					{
						sdz = sdz - 10;
					}
					dj = 1;
					break;
				}
				if (s.x > 440 and s.x < 480 and s.y>210 and s.y < 260)//�ٶ�
				{
					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					if (sdz < 200)
					{
						sdz = sdz + 10;
					}
					dj = 1;
					break;
				}
				if (s.x > 160 and s.x < 200 and s.y>270 and s.y < 320)//�ؿ�
				{
					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					if (gq > 1)
					{
						gq = gq - 1;
					}
					dj = 1;
					break;
				}
				if (s.x > 440 and s.x < 480 and s.y>270 and s.y < 320)//�ؿ�
				{
					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					if (gq < 4)
					{
						gq = gq + 1;
					}
					dj = 1;
					break;
				}
				if (s.x > 160 and s.x < 480 and s.y>330 and s.y < 380)
				{
					mciSendString(_T("close mymusic"), 0, 0, 0);
					mciSendString(_T("close mmusic"), 0, 0, 0);
					mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
					//���Ű�������
					mciSendString(_T("play mmusic "), 0, 0, 0);
					fh = 1;
					dj = 1;
					break;
				}
			}
		}
		break;
	}
}
void chessboard::BGM()
{
	mciSendString(_T("close mymusic"), 0, 0, 0);
	mciSendString(_T("close mmusic"), 0, 0, 0);
	mciSendString(_T("open dj.mp3 alias mmusic "), 0, 0, 0);
	//���Ű�������
	mciSendString(_T("play mmusic "), 0, 0, 0);
	//������
	mciSendString(_T("open Creep.mp3 alias mymusic "), 0, 0, 0);
	//��������
	mciSendString(_T("play mymusic repeat"), 0, 0, 0);
}
void chessboard::jieshu()
{

	loadimage(NULL, _T("./tcs1.png"));

	//�������ֵĴ�С       ����
	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(0, 0, 13));
	//���X��Y������
	rectangle(160, 150, 480, 200);
	settextcolor(RGB(173, 0, 13));
	char ksyx[] = "��Ϸ��ʼ";
	int ksyxwidth = 320 / 2 - textwidth(ksyx) / 2;
	int ksyxheight = 50 / 2 - textheight(ksyx) / 2;
	outtextxy(ksyxwidth + 160, ksyxheight + 150, ksyx);
	//�������ֵĴ�С       ����
	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(0, 0, 13));
	//���X��Y������
	rectangle(160, 210, 480, 260);
	settextcolor(RGB(173, 0, 13));
	char sz[] = "����";
	int szwidth = 320 / 2 - textwidth(sz) / 2;
	int szheight = 50 / 2 - textheight(sz) / 2;
	outtextxy(szwidth + 160, szheight + 210, sz);
	//�������ֵĴ�С       ����
	settextstyle(50, 0, _T("����"));
	setbkmode(TRANSPARENT);
	settextcolor(RGB(0, 0, 13));
	//���X��Y������
	rectangle(160, 270, 480, 330);
	settextcolor(RGB(173, 0, 13));
	char tc[] = "�˳���Ϸ";
	int tcwidth = 320 / 2 - textwidth(tc) / 2;
	int tcheight = 50 / 2 - textheight(tc) / 2;
	outtextxy(tcwidth + 160, tcheight + 270, tc);
	mciSendString(_T("stop mymusic"), 0, 0, 0);
}
void chessboard::kais(){
	while (1) {
		
		for (int i = 0; i < 100; i++)
		{
			cleardevice();
			loadimage(NULL, _T("./jz.png"));
			settextstyle(50, 0, _T("����"));
			setbkmode(TRANSPARENT);
			settextcolor(RGB(173, 0, 13));
			outtextxy(50+i, 360, "������...");
			Sleep(20);
		}
		
		break;
	}

}